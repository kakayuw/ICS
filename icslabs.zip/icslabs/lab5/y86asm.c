#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdbool.h>

#include "y86asm.h"

line_t *y86bin_listhead = NULL;   /* the head of y86 binary code line list*/
line_t *y86bin_listtail = NULL;   /* the tail of y86 binary code line list*/
int y86asm_lineno = 0; /* the current line number of y86 assemble code */

#define err_print(_s, _a ...) do { \
  if (y86asm_lineno < 0) \
    fprintf(stderr, "[--]: "_s"\n", ## _a); \
  else \
    fprintf(stderr, "[L%d]: "_s"\n", y86asm_lineno, ## _a); \
} while (0);

int vmaddr = 0;    /* vm addr */

/* register table */
reg_t reg_table[REG_CNT] = {
    {"%eax", REG_EAX},
    {"%ecx", REG_ECX},
    {"%edx", REG_EDX},
    {"%ebx", REG_EBX},
    {"%esp", REG_ESP},
    {"%ebp", REG_EBP},
    {"%esi", REG_ESI},
    {"%edi", REG_EDI},
};

regid_t find_register(char *name)
{
    int i;
    for (i = 0; i < REG_CNT; i++)
        if (!strncmp(name, reg_table[i].name, SIZEOF_REG))
            return reg_table[i].id;
    return REG_ERR;
}

/* instruction set */
instr_t instr_set[] = {
    {"nop", 3,   HPACK(I_NOP, F_NONE), 1 },
    {"halt", 4,  HPACK(I_HALT, F_NONE), 1 },
    {"rrmovl", 6,HPACK(I_RRMOVL, F_NONE), 2 },
    {"cmovle", 6,HPACK(I_RRMOVL, C_LE), 2 },
    {"cmovl", 5, HPACK(I_RRMOVL, C_L), 2 },
    {"cmove", 5, HPACK(I_RRMOVL, C_E), 2 },
    {"cmovne", 6,HPACK(I_RRMOVL, C_NE), 2 },
    {"cmovge", 6,HPACK(I_RRMOVL, C_GE), 2 },
    {"cmovg", 5, HPACK(I_RRMOVL, C_G), 2 },
    {"irmovl", 6,HPACK(I_IRMOVL, F_NONE), 6 },
    {"rmmovl", 6,HPACK(I_RMMOVL, F_NONE), 6 },
    {"mrmovl", 6,HPACK(I_MRMOVL, F_NONE), 6 },
    {"addl", 4,  HPACK(I_ALU, A_ADD), 2 },
    {"subl", 4,  HPACK(I_ALU, A_SUB), 2 },
    {"andl", 4,  HPACK(I_ALU, A_AND), 2 },
    {"xorl", 4,  HPACK(I_ALU, A_XOR), 2 },
    {"jmp", 3,   HPACK(I_JMP, C_YES), 5 },
    {"jle", 3,   HPACK(I_JMP, C_LE), 5 },
    {"jl", 2,    HPACK(I_JMP, C_L), 5 },
    {"je", 2,    HPACK(I_JMP, C_E), 5 },
    {"jne", 3,   HPACK(I_JMP, C_NE), 5 },
    {"jge", 3,   HPACK(I_JMP, C_GE), 5 },
    {"jg", 2,    HPACK(I_JMP, C_G), 5 },
    {"call", 4,  HPACK(I_CALL, F_NONE), 5 },
    {"ret", 3,   HPACK(I_RET, F_NONE), 1 },
    {"pushl", 5, HPACK(I_PUSHL, F_NONE), 2 },
    {"popl", 4,  HPACK(I_POPL, F_NONE),  2 },
    {".byte", 5, HPACK(I_DIRECTIVE, D_DATA), 1 },
    {".word", 5, HPACK(I_DIRECTIVE, D_DATA), 2 },
    {".long", 5, HPACK(I_DIRECTIVE, D_DATA), 4 },
    {".pos", 4,  HPACK(I_DIRECTIVE, D_POS), 0 },
    {".align", 6,HPACK(I_DIRECTIVE, D_ALIGN), 0 },
    {NULL, 1,    0   , 0 } //end
};

instr_t *find_instr(char *name)
{
	int index = 0;
	for (; instr_set[index].name; index++) 
		if(!strncmp(instr_set[index].name, name, instr_set[index].len))
			return &instr_set[index];
    return NULL;
}

/* symbol table (don't forget to init and finit it) */
symbol_t *symtab = NULL;

/*
 * find_symbol: scan table to find the symbol
 * args
 *     name: the name of symbol
 *
 * return
 *     symbol_t: the 'name' symbol
 *     NULL: not exist
 */
symbol_t *find_symbol(char *name)
{
	symbol_t *tmp = symtab;
	while((tmp = tmp->next) && tmp->name)
		if(!strncmp(tmp->name, name, strlen(name)))
			return tmp;
    return NULL;
}

/*
 * add_symbol: add a new symbol to the symbol table
 * args
 *     name: the name of symbol
 *
 * return
 *     0: success
 *     -1: error, the symbol has exist
 */
int add_symbol(char *name)
{    
	symbol_t *new_sym, *tmp;
    /* check duplicate */
	new_sym = find_symbol(name);
	if(new_sym) {
		err_print("Dup symbol:%s", new_sym->name);
		return -1;
	}
    /* create new symbol_t (don't forget to free it)*/
	new_sym = (symbol_t *) malloc (sizeof(symbol_t));
	new_sym->addr = vmaddr;
	new_sym->name = name;
	new_sym->next = NULL;
    /* add the new symbol_t to symbol table */
 	for(tmp = symtab; tmp->next ; tmp = tmp->next);
 	tmp->next = new_sym;
    return 0;
}

/* relocation table (don't forget to init and finit it) */
reloc_t *reltab = NULL;

/*
 * add_reloc: add a new relocation to the relocation table
 * args
 *     name: the name of symbol
 *
 * return
 *     0: success
 *     -1: error, the symbol has exist
 */
void add_reloc(char *name, bin_t *bin)
{
	reloc_t *new_rel, *tmp;
    /* create new reloc_t (don't forget to free it)*/
    new_rel = (reloc_t *) malloc (sizeof (reloc_t));
    memset(new_rel, 0, sizeof (reloc_t));
    new_rel->name = name;
    new_rel->next = NULL;
    new_rel->y86bin = bin;
    /* add the new reloc_t to relocation table */
    for(tmp = reltab; tmp->next; tmp = tmp->next);
    tmp->next = new_rel;
}


/* macro for parsing y86 assembly code */
#define IS_DIGIT(s) ((*(s)>='0' && *(s)<='9') || *(s)=='-' || *(s)=='+')
#define IS_LETTER(s) ((*(s)>='a' && *(s)<='z') || (*(s)>='A' && *(s)<='Z'))
#define IS_COMMENT(s) (*(s)=='#')
#define IS_REG(s) (*(s)=='%')
#define IS_IMM(s) (*(s)=='$')

#define IS_BLANK(s) (*(s)==' ' || *(s)=='\t')
#define IS_END(s) (*(s)=='\0')

#define SKIP_BLANK(s) do {  \
  while(!IS_END(s) && IS_BLANK(s))  \
    (s)++;    \
} while(0);

/* return value from different parse_xxx function */
typedef enum { PARSE_ERR=-1, PARSE_REG, PARSE_DIGIT, PARSE_SYMBOL, 
    PARSE_MEM, PARSE_DELIM, PARSE_INSTR, PARSE_LABEL} parse_t;

/*
 * parse_instr: parse an expected data token (e.g., 'rrmovl')
 * args
 *     ptr: point to the start of string
 *     inst: point to the inst_t within instr_set
 *
 * return
 *     PARSE_INSTR: success, move 'ptr' to the first char after token,
 *                            and store the pointer of the instruction to 'inst'
 *     PARSE_ERR: error, the value of 'ptr' and 'inst' are undefined
 */
parse_t parse_instr(char **ptr, instr_t **inst)
{
	instr_t *ins;
	char *token = *ptr;
	bool success = true;
    /* skip the blank */
	SKIP_BLANK(token);
	ins = find_instr(token);
	success = !IS_END(token) && ins->name;
	if(success) {
    /* find_instr and check end */
    	*ptr = token + ins->len;
    	*inst = ins;
    	return PARSE_INSTR;
    /* set 'ptr' and 'inst' */
	}else
		return PARSE_ERR;
}

/*
 * parse_delim: parse an expected delimiter token (e.g., ',')
 * args
 *     ptr: point to the start of string
 *
 * return
 *     PARSE_DELIM: success, move 'ptr' to the first char after token
 *     PARSE_ERR: error, the value of 'ptr' and 'delim' are undefined
 */
parse_t parse_delim(char **ptr, char delim)
{
	char *token = *ptr;
	bool success;
    /* skip the blank and check */
	SKIP_BLANK(token);
	success = !IS_END(token) && *token == delim;
	if(success) {
    /* set 'ptr' */
    	*ptr = token + 1;
    	return PARSE_DELIM;
	}else {
		err_print("Invalid '%c'", delim);
    	return PARSE_ERR;
    }
}

/*
 * parse_reg: parse an expected register token (e.g., '%eax')
 * args
 *     ptr: point to the start of string
 *     regid: point to the regid of register
 *
 * return
 *     PARSE_REG: success, move 'ptr' to the first char after token, 
 *                         and store the regid to 'regid'
 *     PARSE_ERR: error, the value of 'ptr' and 'regid' are undefined
 */
parse_t parse_reg(char **ptr, regid_t *regid)
{
	char *token = *ptr;
	regid_t reg = REG_NONE;
	bool success;
    /* skip the blank and check */
	SKIP_BLANK(token);
	/* find register */
	reg = find_register(token);
	success = !IS_END(token) && IS_REG(token) && reg != REG_ERR;
	if(success) {
    /* set 'ptr' and 'regid' */
    	SKIP_BLANK(token);
		*ptr = token + SIZEOF_REG;
		*regid = reg; 
		return PARSE_REG;
	}
	err_print("Invalid REG");
    return PARSE_ERR;
}

/*
 * parse_symbol: parse an expected symbol token (e.g., 'Main')
 * args
 *     ptr: point to the start of string
 *     name: point to the name of symbol (should be allocated in this function)
 *
 * return
 *     PARSE_SYMBOL: success, move 'ptr' to the first char after token,
 *                               and allocate and store name to 'name'
 *     PARSE_ERR: error, the value of 'ptr' and 'name' are undefined
 */
parse_t parse_symbol(char **ptr, char **name) 
{
	char *token = *ptr;
	char *label = *name;
	bool success = true;
	int length = 0;
    /* skip the blank and check */
    SKIP_BLANK(token);
	success = !IS_END(token) && IS_LETTER(token);
	for(; length <= strlen(token); length++)
		if(IS_BLANK(token + length) ||  token[length] == ',')	break;
	if(success) {
    /* allocate name and copy to it */
		label = (char *) malloc (length + 1);
		strncpy(label, token, length);
		*(label + length) = 0;
    /* set 'ptr' and 'name' */
    	*ptr = token + strlen(label);
		*name = label;
    	return PARSE_SYMBOL;
    }else 
		return PARSE_ERR;
}

/*
 * parse_digit: parse an expected digit token (e.g., '0x100')
 * args
 *     ptr: point to the start of string
 *     value: point to the value of digit
 *
 * return
 *     PARSE_DIGIT: success, move 'ptr' to the first char after token
 *                            and store the value of digit to 'value'
 *     PARSE_ERR: error, the value of 'ptr' and 'value' are undefined
 */
parse_t parse_digit(char **ptr, long *value)
{
	char *pEnd;
	char *token = *ptr;
	long int digit;
	bool success = true;
    /* skip the blank and check */
    SKIP_BLANK(token);
	success = !IS_END(token) && IS_DIGIT(token);
	if(success) {
    /* calculate the digit, (NOTE: see strtoll()) */	
		digit = strtoll(token, &pEnd, 0);
    /* set 'ptr' and 'value' */
    	*ptr = pEnd;
		*value = digit;
    	return PARSE_DIGIT;
    }else 
		return PARSE_ERR;
}

/*
 * parse_imm: parse an expected immediate token (e.g., '$0x100' or 'STACK')
 * args
 *     ptr: point to the start of string
 *     name: point to the name of symbol (should be allocated in this function)
 *     value: point to the value of digit
 *
 * return
 *     PARSE_DIGIT: success, the immediate token is a digit,
 *                            move 'ptr' to the first char after token,
 *                            and store the value of digit to 'value'
 *     PARSE_SYMBOL: success, the immediate token is a symbol,
 *                            move 'ptr' to the first char after token,
 *                            and allocate and store name to 'name' 
 *     PARSE_ERR: error, the value of 'ptr', 'name' and 'value' are undefined
 */
parse_t parse_imm(char **ptr, char **name, long *value)
{
	char *token = *ptr;
	char *label;
	long *digit = value;
	bool success = true;
	parse_t parse_state = PARSE_ERR;
    /* skip the blank and check */
	SKIP_BLANK(token);
	success = !IS_END(token);
	if(success) {
    /* if IS_IMM, then parse the digit */
		if(IS_IMM(token)) {
			token ++;
			parse_state = parse_digit(&token, digit);
		}
    /* if IS_LETTER, then parse the symbol */
    	else if(IS_LETTER(token)) {
    		parse_state = parse_symbol(&token, &label);
		}
    	else
    		parse_state = PARSE_ERR; 
    /* set 'ptr' and 'name' or 'value' */
		*ptr = token;
		*name = label;
		value = digit;
	}
	if(parse_state == PARSE_ERR)
		err_print("Invalid Immediate");
    return parse_state;
}

/*
 * parse_mem: parse an expected memory token (e.g., '8(%ebp)')
 * args
 *     ptr: point to the start of string
 *     value: point to the value of digit
 *     regid: point to the regid of register
 *
 * return
 *     PARSE_MEM: success, move 'ptr' to the first char after token,
 *                          and store the value of digit to 'value',
 *                          and store the regid to 'regid'
 *     PARSE_ERR: error, the value of 'ptr', 'value' and 'regid' are undefined
 */
parse_t parse_mem(char **ptr, long *value, regid_t *regid)
{
	char *token = *ptr;
	long digit = 0;
	regid_t reg = REG_NONE;
	bool success;
    /* skip the blank and check */
	SKIP_BLANK(token);
	success = !IS_END(token);
	if(success) {
    /* calculate the digit and register, (ex: (%ebp) or 8(%ebp)) */
		if(IS_DIGIT(token))
			parse_digit(&token, &digit);
		if(*token == '(') {
			token ++;
			parse_reg(&token, &reg);
			if(*token != ')') {
				err_print("Invalid MEM");
				return PARSE_ERR;
			}
			token ++;
		}
		
    /* set 'ptr', 'value' and 'regid' */
    	*ptr = token;
    	*value = digit;
    	*regid = reg;
    	return PARSE_MEM;
	}
	err_print("Invalid MEM");
    return PARSE_ERR;
}

/*
 * parse_data: parse an expected data token (e.g., '0x100' or 'array')
 * args
 *     ptr: point to the start of string
 *     name: point to the name of symbol (should be allocated in this function)
 *     value: point to the value of digit
 *
 * return
 *     PARSE_DIGIT: success, data token is a digit,
 *                            and move 'ptr' to the first char after token,
 *                            and store the value of digit to 'value'
 *     PARSE_SYMBOL: success, data token is a symbol,
 *                            and move 'ptr' to the first char after token,
 *                            and allocate and store name to 'name' 
 *     PARSE_ERR: error, the value of 'ptr', 'name' and 'value' are undefined
 */
parse_t parse_data(char **ptr, char **name, long *value)
{
	char *token = *ptr;
	char *label = *name;
	long digit = 0;
	parse_t parse_state = PARSE_ERR;
	bool success;
    /* skip the blank and check */
	SKIP_BLANK(token);
	success = !IS_END(token);
	if(success) {
    /* if IS_DIGIT, then parse the digit */
		if(IS_DIGIT(token)) {
			parse_state = parse_digit(&token, &digit);
		}
    /* if IS_LETTER, then parse the symbol */
		else if(IS_LETTER(token)) {
			parse_state = parse_symbol(&token, &label);
		}
		else
			parse_state = PARSE_ERR;
    /* set 'ptr', 'name' and 'value' */
    	*ptr = token;
    	*name = label;
    	*value = digit;
    	return parse_state;
	}
    return parse_state;
}

/*
 * parse_label: parse an expected label token (e.g., 'Loop:')
 * args
 *     ptr: point to the start of string
 *     name: point to the name of symbol (should be allocated in this function)
 *
 * return
 *     PARSE_LABEL: success, move 'ptr' to the first char after token
 *                            and allocate and store name to 'name'
 *     PARSE_ERR: error, the value of 'ptr' is undefined
 */
parse_t parse_label(char **ptr, char **name)
{
	char *token = *ptr;
	char *label;
	int index = 0;
	bool success;
    /* skip the blank and check */
	SKIP_BLANK(token);
	for(; token[index] != ':' && index < strlen(token); index++)
		if(IS_COMMENT(token+index))	return PARSE_ERR;
	success = !IS_END(token) && IS_LETTER(token) && index < strlen(token);
	if(success) {
    /* allocate name and copy to it */
		label = (char *) malloc (index+1);
		memset(label, 0, index+1);
		strncpy(label, token, index);
    /* set 'ptr' and 'name' */
    	*ptr = token + index + 1;
    	*name = label;
    	return PARSE_LABEL;
	}
    return PARSE_ERR;
}

/*
 * parse_line: parse a line of y86 code (e.g., 'Loop: mrmovl (%ecx), %esi')
 * (you could combine above parse_xxx functions to do it)
 * args
 *     line: point to a line_t data with a line of y86 assembly code
 *
 * return
 *     PARSE_XXX: success, fill line_t with assembled y86 code
 *     PARSE_ERR: error, try to print err information (e.g., instr type and line number)
 */
type_t parse_line(line_t *line) {
	bin_t *bin = &line->y86bin;
	instr_t *ins = NULL;
	char *token = line->y86asm;
	char *label = NULL, *name = NULL;
	long value = 0;
	parse_t result = 0;
	SKIP_BLANK(token);
	while(!IS_END(token)) {
		SKIP_BLANK(token);
		if(IS_END(token))	break;
		if(IS_COMMENT(token))	break;
		result = parse_label(&token, &label);
		if(result == PARSE_LABEL) {
			if(add_symbol(label) == 0) {
				line->type = TYPE_INS;
				bin->addr = vmaddr;
				continue;
			}else {
				result = PARSE_ERR;
				break; 
			} 
		}
		result = parse_instr(&token, &ins);
		if(result == PARSE_ERR)	break;
		bin->addr = vmaddr;
		bin->bytes = ins->bytes;
		bin->codes[0] = ins->code;
		line->type = TYPE_INS;
		vmaddr += bin->bytes;
		switch(HIGH(ins->code)) {
			case I_HALT: /* 1:0 || halt */
			case I_NOP: /* 2:0 || nop */
			case I_RET: /* 9:0 || ret */
				break;
			case I_IRMOVL: { /* irmovl $-1, %edx || 3:0 F:regB imm */
				regid_t rB = REG_NONE;
				byte_t FrB = 0xff;
				parse_t parseImm;
				result = parse_imm(&token, &name, &value);
				parseImm = result;
				if(result == PARSE_ERR) break;
				result = parse_delim(&token, ',');
				if(result == PARSE_ERR)	break;
				result = parse_reg(&token, &rB);
				if(result == PARSE_ERR) break;
				FrB = HPACK(REG_NONE, rB);
				bin->codes[1] = FrB;
				if(parseImm == PARSE_DIGIT) {
					bin->codes[2] = (byte_t) (value & 0xff); value >>= 8;
					bin->codes[3] = (byte_t) (value & 0xff); value >>= 8;
					bin->codes[4] = (byte_t) (value & 0xff); value >>= 8;
					bin->codes[5] = (byte_t) (value & 0xff);
				}else if(parseImm == PARSE_SYMBOL) {
					add_reloc(name, bin);
				}
				break;
			}
			case I_RMMOVL: { /* rmmovl %ebx, 8(%ecx) || 4:0 regA:regB imm */
				regid_t rA = REG_NONE, rB = REG_NONE;
				byte_t rArB = 0xff;
				result = parse_reg(&token, &rA);
				if(result == PARSE_ERR) break;
				result = parse_delim(&token, ',');
				if(result == PARSE_ERR)	break;
				result = parse_mem(&token, &value, &rB);
				if(result == PARSE_ERR)	break;
				rArB = HPACK(rA, rB);
				bin->codes[1] = rArB;
				bin->codes[2] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[3] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[4] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[5] = (byte_t)(value & 0xff);
				break;				
			}
			case I_MRMOVL: { /* mrmovl 8(%ebp),%ebx || 5:0 regB:regA imm */
				regid_t rA = REG_NONE, rB = REG_NONE;
				byte_t rArB = 0xff;
				result = parse_mem(&token, &value, &rA);
				if(result == PARSE_ERR)	break;
				result = parse_delim(&token, ',');
				if(result == PARSE_ERR)	break;
				result = parse_reg(&token, &rB);
				if(result == PARSE_ERR) break;
				rArB = HPACK(rB, rA);
				bin->codes[1] = rArB;
				bin->codes[2] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[3] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[4] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[5] = (byte_t)(value & 0xff);
				break;
			}
			case I_RRMOVL: /* rrmovl %ebx, %eax || 2:x regA:regB */
			case I_ALU: { /* add %edx, %eax || 6:x regA:regB */
				regid_t rA = REG_NONE, rB = REG_NONE;
				byte_t rArB = 0Xff;
				result = parse_reg(&token, &rA);
				if(result == PARSE_ERR) break;
				result = parse_delim(&token, ',');
				if(result == PARSE_ERR)	break;
				result = parse_reg(&token, &rB);
				if(result == PARSE_ERR) break;
				rArB = HPACK(rA, rB);
				bin->codes[1] = rArB;				
				break;
			}
			case I_JMP: /* jmp 0x0x86490000 jmp Pos || 7:x imm */
			case I_CALL: { /* call printf || 8:x imm */
				result = parse_data(&token, &name, &value);
				if(result == PARSE_SYMBOL) {
					add_reloc(name, bin);
				}else if(result == PARSE_DIGIT) {
					line_t *tmpline = y86bin_listhead -> next;
					bool invalid_addr = true;
					for(; tmpline->next; tmpline = tmpline->next)
						if(tmpline->y86bin.addr == value)
							invalid_addr = false;
					if(invalid_addr) {
						err_print("Invalid DEST");
						result = PARSE_ERR;}
				}
				bin->codes[1] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[2] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[3] = (byte_t)(value & 0xff); value >>= 8;
				bin->codes[4] = (byte_t)(value & 0xff);
				break;
			}
			case I_PUSHL: /* A:0 regA:F */
			case I_POPL: { /* B:0 regA:F */
				regid_t rA = REG_NONE;
				byte_t rAF = 0xf;
				result = parse_reg(&token, &rA);
				if(result == PARSE_ERR) break;
				rAF = HPACK(rA, REG_NONE);
				bin->codes[1] = rAF;
				break;
			}
			case I_DIRECTIVE: {
				byte_t low = LOW(ins->code);
				if(low == D_DATA) {
					result = parse_data(&token, &name, &value);
					if(result == PARSE_SYMBOL) {
						add_reloc(name,bin);
					}else if(result == PARSE_DIGIT) {
						bin->codes[0] = (byte_t)(value & 0xff); value >>= 8;
						bin->codes[1] = (byte_t)(value & 0xff); value >>= 8;
						bin->codes[2] = (byte_t)(value & 0xff); value >>= 8;
						bin->codes[3] = (byte_t)(value & 0xff);						
					}
					break;
				}else if(low == D_POS) {
					result = parse_digit(&token, &value);
					if(result == PARSE_DIGIT) {
						vmaddr = value;
						bin->addr = vmaddr;
					}else if(result == PARSE_ERR);
					break;
				}else if(low == D_ALIGN) {
					result = parse_digit(&token, &value);
					if(result == PARSE_DIGIT) {
						int add = value - vmaddr % value;
						vmaddr += (add == value) ? 0: add;
						bin->addr = vmaddr;
					}else if(result == PARSE_ERR);
					break;
				}else {
					result = PARSE_ERR;
					break;
				}
			}
			default :
				result = PARSE_ERR;
				break;
		}
		if(result == PARSE_ERR)	break;
		
		SKIP_BLANK(token);
	}
	if(result == PARSE_ERR)	line->type = TYPE_ERR;
	return line->type;
}


/*
 * assemble: assemble an y86 file (e.g., 'asum.ys')
 * args
 *     in: point to input file (an y86 assembly file)
 *
 * return
 *     0: success, assmble the y86 file to a list of line_t
 *     -1: error, try to print err information (e.g., instr type and line number)
 */
int assemble(FILE *in)
{
    static char asm_buf[MAX_INSLEN]; /* the current line of asm code */
    line_t *line;
    int slen;
    char *y86asm;

    /* read y86 code line-by-line, and parse them to generate raw y86 binary code list */
    while (fgets(asm_buf, MAX_INSLEN, in) != NULL) {
        slen  = strlen(asm_buf);
        if ((asm_buf[slen-1] == '\n') || (asm_buf[slen-1] == '\r')) { 
            asm_buf[--slen] = '\0'; /* replace terminator */
        }

        /* store y86 assembly code */
        y86asm = (char *)malloc(sizeof(char) * (slen + 1)); // free in finit
        strcpy(y86asm, asm_buf);

        line = (line_t *)malloc(sizeof(line_t)); // free in finit
        memset(line, '\0', sizeof(line_t));

        /* set defualt */
        line->type = TYPE_COMM;
        line->y86asm = y86asm;
        line->next = NULL;

        /* add to y86 binary code list */
        y86bin_listtail->next = line;
        y86bin_listtail = line;
        y86asm_lineno ++;

        /* parse */
        if (parse_line(line) == TYPE_ERR)
            return -1;
    }

    /* skip line number information in err_print() */
    y86asm_lineno = -1;
    return 0;
}

/*
 * relocate: relocate the raw y86 binary code with symbol address
 *
 * return
 *     0: success
 *     -1: error, try to print err information (e.g., addr and symbol)
 */
int relocate(void)
{
	reloc_t *tmp = reltab->next;
	symbol_t *smb = symtab;
	int beg, value;
	byte_t *codes = NULL;
	for(; tmp; tmp = tmp->next) {
        /* find symbol */
		smb = find_symbol(tmp->name);
        /* relocate y86bin according itype */ 
		if(smb) {
			beg = tmp->y86bin->bytes - 4;
			codes = tmp->y86bin->codes + beg;
			value = smb->addr;
			codes[0] = (byte_t) (value & 0xff); value >>= 8;
			codes[1] = (byte_t) (value & 0xff); value >>= 8;
			codes[2] = (byte_t) (value & 0xff); value >>= 8;
			codes[3] = (byte_t) (value & 0xff);
		}else {
			err_print("Unknown symbol:'%s'", tmp->name);
			return -1;
		}
	}
    return 0;
}

/*
 * binfile: generate the y86 binary file
 * args
 *     out: point to output file (an y86 binary file)
 *
 * return
 *     0: success
 *     -1: error
 */
int binfile(FILE *out)
{
	line_t *line = y86bin_listhead->next;
	int address = 0, next_addr = 0, bytes = 0, i;
	byte_t* pad = (byte_t *) malloc (sizeof (byte_t));
	memset(pad, 0 , sizeof (byte_t));
    /* prepare image with y86 binary code */
	for(; line; line = line->next) {
		address = (address <= line->y86bin.addr) ? line->y86bin.addr : address;
		bytes = (address <= line->y86bin.addr) ? line->y86bin.bytes : bytes;
		next_addr = (line->next) ? line->next->y86bin.addr : next_addr;
		/* binary write y86 code to output file (NOTE: see fwrite()) */
		fwrite(line->y86bin.codes, sizeof(byte_t), line->y86bin.bytes, out);
		if (address + bytes < next_addr){
			line_t *lt_line = line->next->next; 
			if(lt_line->next && lt_line->y86asm[0] != 'S')
				for(i = 0; i < next_addr - (address + bytes); i++)
					fwrite(pad,sizeof(byte_t),1,out);
		}
	}
    return 0;
}


/* whether print the readable output to screen or not ? */
bool_t screen = FALSE; 

static void hexstuff(char *dest, int value, int len)
{
    int i;
    for (i = 0; i < len; i++) {
        char c;
        int h = (value >> 4*i) & 0xF;
        c = h < 10 ? h + '0' : h - 10 + 'a';
        dest[len-i-1] = c;
    }
}

void print_line(line_t *line)
{
    char buf[26];

    /* line format: 0xHHH: cccccccccccc | <line> */
    if (line->type == TYPE_INS) {
        bin_t *y86bin = &line->y86bin;
        int i;
        
        strcpy(buf, "  0x000:              | ");
        
        hexstuff(buf+4, y86bin->addr, 3);
        if (y86bin->bytes > 0)
            for (i = 0; i < y86bin->bytes; i++)
                hexstuff(buf+9+2*i, y86bin->codes[i]&0xFF, 2);
    } else {
        strcpy(buf, "                      | ");
    }

    printf("%s%s\n", buf, line->y86asm);
}

/* 
 * print_screen: dump readable binary and assembly code to screen
 * (e.g., Figure 4.8 in ICS book)
 */
void print_screen(void)
{
    line_t *tmp = y86bin_listhead->next;
    
    /* line by line */
    while (tmp != NULL) {
        print_line(tmp);
        tmp = tmp->next;
    }
}

/* init and finit */
void init(void)
{
    reltab = (reloc_t *)malloc(sizeof(reloc_t)); // free in finit
    memset(reltab, 0, sizeof(reloc_t));

    symtab = (symbol_t *)malloc(sizeof(symbol_t)); // free in finit
    memset(symtab, 0, sizeof(symbol_t));

    y86bin_listhead = (line_t *)malloc(sizeof(line_t)); // free in finit
    memset(y86bin_listhead, 0, sizeof(line_t));
    y86bin_listtail = y86bin_listhead;
    y86asm_lineno = 0;
}

void finit(void)
{
    reloc_t *rtmp = NULL;
    do {
        rtmp = reltab->next;
        if (reltab->name) 
            free(reltab->name);
        free(reltab);
        reltab = rtmp;
    } while (reltab);
    
    symbol_t *stmp = NULL;
    do {
        stmp = symtab->next;
        if (symtab->name) 
            free(symtab->name);
        free(symtab);
        symtab = stmp;
    } while (symtab);

    line_t *ltmp = NULL;
    do {
        ltmp = y86bin_listhead->next;
        if (y86bin_listhead->y86asm) 
            free(y86bin_listhead->y86asm);
        free(y86bin_listhead);
        y86bin_listhead = ltmp;
    } while (y86bin_listhead);
}

static void usage(char *pname)
{
    printf("Usage: %s [-v] file.ys\n", pname);
    printf("   -v print the readable output to screen\n");
    exit(0);
}

int main(int argc, char *argv[])
{
    int rootlen;
    char infname[512];
    char outfname[512];
    int nextarg = 1;
    FILE *in = NULL, *out = NULL;
    
    if (argc < 2)
        usage(argv[0]);
    
    if (argv[nextarg][0] == '-') {
        char flag = argv[nextarg][1];
        switch (flag) {
          case 'v':
            screen = TRUE;
            nextarg++;
            break;
          default:
            usage(argv[0]);
        }
    }

    /* parse input file name */
    rootlen = strlen(argv[nextarg])-3;
    /* only support the .ys file */
    if (strcmp(argv[nextarg]+rootlen, ".ys"))
        usage(argv[0]);
    
    if (rootlen > 500) {
        err_print("File name too long");
        exit(1);
    }


    /* init */
    init();

    
    /* assemble .ys file */
    strncpy(infname, argv[nextarg], rootlen);
    strcpy(infname+rootlen, ".ys");
    in = fopen(infname, "r");
    if (!in) {
        err_print("Can't open input file '%s'", infname);
        exit(1);
    }
    
    if (assemble(in) < 0) {
        err_print("Assemble y86 code error");
        fclose(in);
        exit(1);
    }
    fclose(in);


    /* relocate binary code */
    if (relocate() < 0) {
        err_print("Relocate binary code error");
        exit(1);
    }


    /* generate .bin file */
    strncpy(outfname, argv[nextarg], rootlen);
    strcpy(outfname+rootlen, ".bin");
    out = fopen(outfname, "wb");
    if (!out) {
        err_print("Can't open output file '%s'", outfname);
        exit(1);
    }

    if (binfile(out) < 0) {
        err_print("Generate binary file error");
        fclose(out);
        exit(1);
    }
    fclose(out);
    
    /* print to screen (.yo file) */
    if (screen)
       print_screen(); 

    /* finit */
    finit();
    return 0;
}


