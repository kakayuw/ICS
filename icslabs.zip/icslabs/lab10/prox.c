/*
 * proxy.c - CS:APP Web proxy
 *
 * name: yuhang
 * sID: 515030910284
 * email: yuhang012@sjtu.edu.cn
 *
 * TEAM MEMBERS:
 *     Andrew Carnegie, ac00@cs.cmu.edu 
 *     Harry Q. Bovik, bovik@cs.cmu.edu
 * 
 * IMPORTANT: Give a high level description of your code here. You
 * must also provide a header comment at the beginning of each
 * function that describes what that function does.
 * 
 *  The Proxy takes the model recommended in the chapter 12 referred as producer-consumer model and takes the
 *  tecnique of prethreading methon to provide concurrent server. It create a new thread for each new client.
 *  The server consists of a main thread and a set of worker threads.The main thread repeatedly accepts connection
 *  requests from clients and places the resulting connected descriptors in a bounded buffer. Each worker thread
 *  repeatedly removes a descriptor from the buffer, services the client, and then waits for the next descriptor.
 */ 

#include "csapp.h"

#define NTHREADS 4
#define SBUFSIZE 16

/*
 * typedef structs
 */
typedef struct {
    int clientfd;
    struct sockaddr_in addr; 
} client_info;

typedef struct {
    client_info **buf;   /* Buffer array */
    int n;                     /* Maximum number of slots */
    int front;                 /* buf[(front+1)%n] is first item */
    int rear;                  /* buf[rear%n] is last item */
    sem_t mutex;               /* Protects accesses to buf */
    sem_t slots;               /* Counts available slots */
    sem_t items;               /* Counts available items */
} sbuf_t;

/*
 * Function prototypes
 */
int parse_uri(char *uri, char *target_addr, char *path, int  *port);
void format_log_entry(char *logstring, struct sockaddr_in *sockaddr, char *uri, int size);
void doit(client_info *fd);
void clienterror(int fd, char *cause, char *errnum, char *shortmsg, char *longmsg);
void serve_static(int clientFd, int serverFd, char *uri, struct sockaddr_in clientaddr, int size);
void serve_dynamic(int fd, char *filename, char *cgiargs);
int parse_uri_sd(char *uri, char *filename, char *cgiargs);

ssize_t Rio_readnb_w(rio_t *rp, void *usrbuf, size_t n);
ssize_t Rio_readlineb_w(rio_t *rp, void *usrbuf, size_t maxlen);
int Rio_writen_w(int fd, void *usrbuf, size_t n);
int Open_clientfd_ts(char *hostname, int port);

void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, client_info *addr);
client_info *sbuf_remove(sbuf_t *sp);

void *thread(void *vargp);

/*
 * Global variables
 */
sbuf_t sbuf;
sem_t open_clientfd_mutex;
sem_t logfile_mutex;

/* 
 * main - Main routine for the proxy program 
 */
int main(int argc, char **argv)
{
    int listenfd, port, i;
    //struct sockaddr_in clientaddr;
    socklen_t clientlen = sizeof(struct sockaddr_in);
    pthread_t tid;
    /* Check arguments */
    if (argc != 2) {
	    fprintf(stderr, "Usage: %s <port number>\n", argv[0]);
	    exit(0);
    }
    Signal(SIGPIPE, SIG_IGN);
    port = atoi(argv[1]);
    Sem_init(&open_clientfd_mutex, 0, 1);
    Sem_init(&logfile_mutex, 0, 1);
    sbuf_init(&sbuf, SBUFSIZE);
    listenfd = Open_listenfd(port);
    
    for (i = 0; i < NTHREADS; i++ ) /* Create worker threads */
        Pthread_create(&tid, NULL, thread, NULL);

    while (1) {

        client_info *cli = (client_info *) Malloc(sizeof (client_info));
        cli->clientfd = Accept(listenfd, (SA *) &cli->addr, &clientlen );;
        
        sbuf_insert(&sbuf, cli); /* Insert connfd in buffer */
    }
    exit(0);
}

void *thread(void *vargp)
{
    Pthread_detach(Pthread_self());
    while (1) {
        client_info *cli = sbuf_remove(&sbuf);    /* Remove connfd from buffer */
        doit(cli);                   /* Service client */
    }
    return NULL;
}

void doit(client_info *cli)
{
    int is_static, port, serverFd, clientFd = cli->clientfd;
    struct sockaddr_in clientaddr = cli->addr;
    struct stat stbuf;
    char buf[MAXLINE], cgiargs[MAXLINE];
    char serverBuf[MAXLINE], clientBuf[MAXLINE];
    char method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char filename[MAXLINE], pathname[MAXLINE], hostname[MAXLINE];
    rio_t cRio;

    /* Read request line and headers */
    Rio_readinitb(&cRio, clientFd);
    if(Rio_readlineb_w(&cRio, buf, MAXLINE) < 0)  return;
    sscanf(buf, "%s %s %s", method, uri, version);
    if (strcasecmp(method, "GET")) {
        clienterror(clientFd, method, "501", "Not Implemented", "Tiny does not implement this method");
        return;
    }
    is_static = parse_uri(uri, hostname, pathname, &port);
    if((serverFd = Open_clientfd_ts(hostname, port)) < 0){
        strcpy(serverBuf, "Server connect error.");
        Rio_writen_w(clientFd, serverBuf, strlen(serverBuf));
        return;
    }
    sprintf(clientBuf, "%s %s %s\r\n", method, pathname, version);
    /* Read and handle the request header */
    while (strcmp(buf, "\r\n") != 0) {
        Rio_readlineb_w(&cRio, buf, MAXLINE);
        strcat(clientBuf, buf);
    }
    Rio_writen_w(serverFd, clientBuf, sizeof(clientBuf));

    /* Parse URI from GET request */
    is_static = parse_uri_sd(uri, filename, cgiargs);

    if (is_static) { /* Serve static content */
        serve_static(clientFd, serverFd, uri, clientaddr, stbuf.st_size);
    } else { /* Serve dynamic content */
        if (!(S_ISREG(stbuf.st_mode)) || !(S_IXUSR & stbuf.st_mode)) {
            clienterror(clientFd, filename, "403", "Forbidden", "Tiny couldn’t run the CGI program");
            return;
        }
        serve_dynamic(clientFd, filename, cgiargs);
    }
}

/* --sbuf function definations --*/

/* Create an empty, bounded shared FIFO buffer with  slots */
void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = Calloc(n, sizeof(int));
    sp->n = n;
    sp->front = 0;
    sp->rear = 0;
    Sem_init(&sp->mutex, 0, 1);
    Sem_init(&sp->slots, 0, n);
    Sem_init(&sp->items, 0, 0);
}

/* Clean up buffer sp */
void sbuf_deinit(sbuf_t *sp)
{
    Free(sp->buf);
}

/* Insert item onto the rear of shared buffer sp */
void sbuf_insert(sbuf_t *sp, client_info *item)
{
    P(&sp->slots);                      /* Wait for available slot */
    P(&sp->mutex);                      /* Lock the buffer */
    sp->buf[(++sp->rear)%(sp->n)] = item;  /* Insert the item */
    V(&sp->mutex);                      /* Unlock the buffer */
    V(&sp->items);                      /* Announce availabe item */
}

/* Remove and return the first item from buffer sp */
client_info* sbuf_remove(sbuf_t *sp)
{
    client_info *item;
    P(&sp->items);                      /* Wait for available item */
    P(&sp->mutex);                      /* Lock the buffer */
    item = sp->buf[(++sp->front)%(sp->n)];  /*remove the item */
    V(&sp->mutex);                      /* Unlock the buffer */
    V(&sp->slots);                      /* Announce availabe slot */
    return item;
}


void clienterror(int fd, char *cause, char *errnum, char *shortmsg, char *longmsg)
{
    char buf[MAXLINE], body[MAXBUF];
    
    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    Rio_writen_w(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    Rio_writen_w(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    Rio_writen_w(fd, buf, strlen(buf));
    Rio_writen_w(fd, body, strlen(body));
}

void serve_static(int clientFd, int serverFd, char *uri, struct sockaddr_in clientaddr, int filesize)
{
    rio_t sRio;
    int n;
    char buf[MAXLINE];

    /* Send response body to client */
    Rio_readinitb(&sRio, serverFd);
    while((n = Rio_readnb_w(&sRio, buf, MAXLINE)) > 0){
        if(Rio_writen_w(clientFd, buf, n) != n)
            break;
    }       
    Close(serverFd);
    // Format string to be logged
    format_log_entry(buf, &clientaddr, uri, filesize);
    P(&logfile_mutex);
    FILE* logfile = Fopen("proxy.log", "a");
    fprintf(logfile, "%s", buf);
    Fclose(logfile);
    Close(clientFd);
    V(&logfile_mutex);
    return;

}

void serve_dynamic(int fd, char *filename, char *cgiargs)
{
    char buf[MAXLINE], *emptylist[] = { NULL };
    
    /* Return first part of HTTP response */
    sprintf(buf, "HTTP/1.0 200 OK\r\n");
    Rio_writen_w(fd, buf, strlen(buf));
    sprintf(buf, "Server: Tiny Web Server\r\n");
    Rio_writen_w(fd, buf, strlen(buf));
  
    if (Fork() == 0) { /* child */
        /* Real server would set all CGI vars here */
        setenv("QUERY_STRING", cgiargs, 1);
        Dup2(fd, STDOUT_FILENO); /* Redirect stdout to client */
        Execve(filename, emptylist, environ); /* Run CGI program */
    }
    Wait(NULL); /* Parent waits for and reaps child */
}

/* Parse uri to get filename and the static or dynamic attribute of the file */
int parse_uri_sd(char *uri, char *filename, char *cgiargs)
{
    char *ptr;
    char hostname[MAXLINE], pathname[MAXLINE];
    int port;
    parse_uri(uri, hostname, pathname, &port);
    if (!strstr(uri, "cgi-bin")) {  /* Static content */
        strcpy(cgiargs, "");
        strcpy(filename, hostname);
        strcat(filename, pathname);
        if (uri[strlen(uri)-1] == '/')
            strcat(filename, "home.html");
        return 1;
    }
    else { /* Dynamic content */
        ptr = index(uri, '?');
        if (ptr) {
            strcpy(cgiargs, ptr+1);
            *ptr = '\0';
        } else
            strcpy(cgiargs, "");
        strcpy(filename, ".");
        strcat(filename, uri);
        return 0;
    }
}


/*
 * parse_uri - URI parser
 * 
 * Given a URI from an HTTP proxy GET request (i.e., a URL), extract
 * the host name, path name, and port.  The memory for hostname and
 * pathname must already be allocated and should be at least MAXLINE
 * bytes. Return -1 if there are any problems.
 */
int parse_uri(char *uri, char *hostname, char *pathname, int *port)
{
    char *hostbegin;
    char *hostend;
    char *pathbegin;
    int len;

    if (strncasecmp(uri, "http://", 7) != 0) {
        hostname[0] = '\0';
        return -1;
    }

    *port = 80; /* default */

    /* Extract the host name */
    hostbegin = uri + 7;
    hostend = strpbrk(hostbegin, " :/\r\n");
    len = hostend - hostbegin;
    if(strlen(hostbegin) < len){
        // Failed to find the characters
        strcpy(hostname, hostbegin);
        strcpy(pathname, "/");
        return 0;
    }
    strncpy(hostname, hostbegin, len);
    hostname[len] = '\0';

    /* Extract the port number */
    if (*hostend == ':')
        *port = atoi(hostend + 1);

    /* Extract the path */
    pathbegin = strchr(hostbegin, '/');
    if (pathbegin == NULL)
        pathname[0] = '\0';
    else
        strcpy(pathname, pathbegin);

    return 0;
}

/*
 * format_log_entry - Create a formatted log entry in logstring. 
 * 
 * The inputs are the socket address of the requesting client
 * (sockaddr), the URI from the request (uri), and the size in bytes
 * of the response from the server (size).
 */
void format_log_entry(char *logstring, struct sockaddr_in *sockaddr, char *uri, int size)
{
    time_t now;
    char time_str[MAXLINE];
    unsigned long host;
    unsigned char a, b, c, d;

    /* Get a formatted time string */
    now = time(NULL);
    strftime(time_str, MAXLINE, "%a %d %b %Y %H:%M:%S %Z", localtime(&now));

    /* 
     * Convert the IP address in network byte order to dotted decimal
     * form. Note that we could have used inet_ntoa, but chose not to
     * because inet_ntoa is a Class 3 thread unsafe function that
     * returns a pointer to a static variable (Ch 13, CS:APP).
     */
    host = ntohl(sockaddr->sin_addr.s_addr);
    a = host >> 24;
    b = (host >> 16) & 0xff;
    c = (host >> 8) & 0xff;
    d = host & 0xff;


    /* Return the formatted log entry string */
    sprintf(logstring, "%s: %d.%d.%d.%d %s", time_str, a, b, c, d, uri);
}


/* -- robust IO function wrappers -- */

ssize_t Rio_readnb_w(rio_t *rp, void *usrbuf, size_t n) {
    ssize_t rc;

    if ((rc = Rio_readnb(rp, usrbuf, n)) < 0) {
        printf("Rio_readnb function error\n");
        return 0;
    }
    return rc;
}

ssize_t Rio_readlineb_w(rio_t *rp, void *usrbuf, size_t maxlen) {
    ssize_t rc;

    if ((rc = Rio_readlineb(rp, usrbuf, maxlen)) < 0) {
        printf("Rio_readlineb function error\n");
        return 0;
    }
    return rc;
} 

int Rio_writen_w(int fd, void *usrbuf, size_t n) 
{
    int rc;
    if ((rc = rio_writen(fd, usrbuf, n)) != n) {
        printf("Rio_writen function error\n");
        return -1;
    }
    return rc;
}

/*  Thread-safe version of open clientfd */
int Open_clientfd_ts(char *hostname, int port)
{
    int clientfd;
    struct hostent *raw_hp, *hp;
    struct sockaddr_in serveraddr;

    if ((clientfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        return -1; /* check errno for cause of error */

    /* Fill in the server's IP address and port */
    P(&open_clientfd_mutex);
    if ((raw_hp = gethostbyname(hostname)) == NULL)
        return -2; /* check h_errno for cause of error */

    hp = Malloc(sizeof(struct hostent));
    memcpy(hp, raw_hp, sizeof(struct hostent));
    V(&open_clientfd_mutex);

    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)hp->h_addr_list[0],
          (char *)&serveraddr.sin_addr.s_addr, hp->h_length);
    serveraddr.sin_port = htons(port);
    Free(hp);

    /* Establish a connection with the server */
    if (connect(clientfd, (SA *) &serveraddr, sizeof(serveraddr)) < 0)
        return -1;
    return clientfd;
}
