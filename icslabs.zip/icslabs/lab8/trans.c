/* 
 * trans.c - Matrix transpose B = A^T
 *
 * name: yuhang 
 * studentID: 515030910284
 *
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	int i, j, k, v1, v2, v3, v4, v5, v6, v7, v8;
	if(M == 32 && N == 32) {
		for(j = 0; j < N; j += 8) {
			for(i = 0; i< M; i++) {
				v1 = A[i][j];
				v2 = A[i][j+1];
				v3 = A[i][j+2];
				v4 = A[i][j+3];
				v5 = A[i][j+4];
				v6 = A[i][j+5];
				v7 = A[i][j+6];
				v8 = A[i][j+7];
				B[j][i] = v1;
				B[j+1][i] = v2;
				B[j+2][i] = v3;
				B[j+3][i] = v4;	
				B[j+4][i] = v5;
				B[j+5][i] = v6;
				B[j+6][i] = v7;
				B[j+7][i] = v8;						
			}
		}
	} else if(M == 64 && N == 64) {
		/* seperate into 8 X 8 blocks 
		    each block is seperated into 4 area

			*************************
            *           *           *
            *           *           *
            *      1    *      2    *
            *           *           *
            *           *           *
            *           *           *
		    *************************
            *           *           *
            *           *           *
            *           *           *
            *     3     *      4    *
            *           *           *
            *           *           *
            *           *           *
		    *************************
			
			To avoid miss, load A1 -> B1, A2 -> B2,
			then load B2 -> local -> B3, A3 -> B2, A4 -> B4;
		*/
		for( j = 0; j < M; j += 8) {
			for( i = 0; i < N; i += 8) {
				for( k = 0; k < 4; k++) {
					/* save A1 A2 to B1 B3*/
					v1 = A[j + k][i];
					v2 = A[j + k][i + 1];
					v3 = A[j + k][i + 2];
					v4 = A[j + k][i + 3];
					v5 = A[j + k][i + 4];
					v6 = A[j + k][i + 5];
					v7 = A[j + k][i + 6];
					v8 = A[j + k][i + 7];
					/* A1 -> B2 */
					B[i][j + k] = v1;
					B[i + 1][j + k] = v2;
					B[i + 2][j + k] = v3;
					B[i + 3][j + k] = v4;
					/* A2 -> B2 */
					B[i][j + k + 4] = v5;
					B[i + 1][j + k + 4] = v6;
					B[i + 2][j + k + 4] = v7;
					B[i + 3][j + k + 4] = v8;

				}
				for( k = i; k < i + 4; k++) {
					/* B2 -> local */
					v1 = B[k][j + 4];
					v2 = B[k][j + 5];
					v3 = B[k][j + 6];
					v4 = B[k][j + 7];
					/* A3 -> B2 */
					B[k][j + 4] = A[j + 4][k];
					B[k][j + 5] = A[j + 5][k];
					B[k][j + 6] = A[j + 6][k];
					B[k][j + 7] = A[j + 7][k];
					/* local -> B3 */
					B[k + 4][j] = v1;
					B[k + 4][j + 1] = v2;
					B[k + 4][j + 2] = v3;
					B[k + 4][j + 3] = v4;
					/* A4 -> B4 */
					B[k + 4][j + 4] = A[j + 4][k + 4];
					B[k + 4][j + 5] = A[j + 5][k + 4];
					B[k + 4][j + 6] = A[j + 6][k + 4];
					B[k + 4][j + 7] = A[j + 7][k + 4];	

				}

			}
		}
	} else if(M == 61 && N == 67) {
        for (i = 0; i < 64; i += 8) {
            for (j = 0; j < 61; j++) {
                v1 = A[i][j];
                v2 = A[i+1][j];
                v3 = A[i+2][j];
                v4 = A[i+3][j];
                v5 = A[i+4][j];
                v6 = A[i+5][j];
                v7 = A[i+6][j];
                v8 = A[i+7][j];
                B[j][i] = v1;
                B[j][i+1] = v2;
                B[j][i+2] = v3;
                B[j][i+3] = v4;
                B[j][i+4] = v5;
                B[j][i+5] = v6;
                B[j][i+6] = v7;
                B[j][i+7] = v8;
            }
        }
        for (j = 0; j < 61; j++) {
        	for(i = 64; i < 67; i++)
        		B[j][i] = A[i][j];
        }
	} else {
	    for (i = 0; i < N; i++) {
	        for (j = 0; j < M; j++) {
	            v1 = A[i][j];
	            B[j][i] = v1;
	        }
	    } 		
	}
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    //registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

