/* name: yuhang
 * student ID: 515030910284
 */ 
#include "cachelab.h"
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>

#define GETLINEN 64
#define HIT 1
#define MISS 2
//miss and eviction
#define MISSEVIC 3
//miss and hit
#define MISSHIT 4
//miss eviction and hit
#define MEH 5
#define MASK (0x7fffffff)

typedef struct {
	int valid;
	int tag;
	int time;
}line_t;

typedef struct {
	line_t *line;
	int number;
}set_t;

typedef struct {
	int setN;
	int lineN;
	set_t *sets;
}cache_t;

typedef struct {
	int s;
	int E;
	int b;
	int flag;
	char trace[20];
}cache_state;

typedef struct {
	int hit;
	int miss;
	int eviction;
}result_t;

typedef struct {
	int seti;
	int linei;
}update_t;


cache_state *getState(int argc, char *argv[]);
cache_t *cacheInit(cache_state *state);
result_t *parseTraces(cache_state *state, cache_t *cache);
int parseLine(cache_state *state, cache_t *cache, char *line, result_t *rst, update_t *ut);
int updateLRU(cache_t *cache, update_t *ut);



/* main */
int main(int argc, char *argv[])
{
	
	cache_state *state = getState(argc, argv);
	cache_t *cache = cacheInit(state);
	result_t *rst = parseTraces(state, cache);
	printSummary(rst->hit, rst->miss, rst->eviction);
    return 0;
}

/*
 * getState() parse the command line input and initialize the
 * necessary parameters in the struct cache_state;
 */
cache_state *getState(int argc, char *argv[]) {
	cache_state *state = (cache_state *)malloc(sizeof(cache_state));
	state->flag = 0;
	int ch;
	opterr = 0;
	while( (ch = getopt(argc, argv, "hvs:E:b:t:")) != -1 ) {
		switch(ch) {
			case 'v':
				state->flag = 1;
				break;
			case 's':
				state->s = atoi(optarg);
				break;
			case 'E':
				state->E = atoi(optarg);
				break;
			case 'b':
				state->b = atoi(optarg);
				break;
			case 't':{
				strcpy(state->trace, optarg);
				break;
			}
			default:
				break;
		}
	}
	return state;
}

/* cacheInit() malloc the memory of sets and lines and set valid flag */
cache_t *cacheInit(cache_state *state) {
	int i, j;
	cache_t *cache = (cache_t *) malloc (sizeof(cache_t));
	cache->setN = (2 << state->s);
	cache->lineN = state->E;
	cache->sets = (set_t *) malloc(cache->setN * sizeof(set_t));
	for(i = 0; i < cache->setN; i++) {
		cache->sets[i].line = (line_t *) malloc(cache->lineN * sizeof(line_t));
		for(j = 0; j < cache->lineN; j++) {
			cache->sets[i].line[j].valid = 0;
		}
	} 
	return cache;
}


/* parseTraces() read the object file and parse the input by lines */
result_t *parseTraces(cache_state *state, cache_t *cache) {
	char line[GETLINEN];
	result_t *result = (result_t *) malloc (sizeof(result_t));
	update_t *ut = (update_t *) malloc (sizeof(update_t));
	FILE *fp = fopen(state->trace, "r");
	while (fgets(line, GETLINEN, fp)) {
		if (line[0] != ' ')	continue;
		int stt = 0;
		stt = parseLine(state, cache, line, result, ut);
		updateLRU(cache, ut);
		if(state->flag != 1) continue;
		switch (stt) {
			case HIT:
				printf("%s hit\n", line);
				break;
			case MISS:
				printf("%s miss\n", line);
				break;
			case MISSHIT:
				printf("%s miss hit\n", line);
				break;
			case MISSEVIC:
				printf("%s miss eviction\n", line);
				break;
			case MEH:
				printf("%s miss eviction hit\n", line);
				break;
			default:
				break;
		}
	}
	fclose(fp); 
	return result;
}

/* parseLine() search the cache for legal address and return the type of this search */
int parseLine(cache_state *state, cache_t *cache, char *line, result_t *rst, update_t *ut) {
	int type = 0, i, addr;
	char ch;
	int seti, tag;
	line_t *block = (line_t *) malloc (sizeof(line_t));
	sscanf(line, " %c %x", &ch, &addr);
	seti = (addr >> state->b) & (MASK >> (31 - state->s));
	tag = (addr >> (state->s + state->b))  &  (MASK >> (31- state->s - state->b));
	for(i = 0; i < cache->lineN; i++) {
		block = &cache->sets[seti].line[i];
		if (block->valid == 1 && tag == block->tag) {
			rst->hit ++;
			if (ch == 'M') rst->hit ++;
			ut->seti = seti;
			ut->linei = i;
			return HIT;
		}
	}
	rst->miss ++;
	for(i = 0; i < cache->lineN; i++) {
		block = &cache->sets[seti].line[i];
		if(block->valid == 0) {
			block->valid = 1;
			block->tag = tag;
			ut->seti = seti;
			ut->linei = i;
			if(ch == 'M') {
				rst->hit ++;
				return MISSHIT;
			} else
				return MISS;
		}
	}
	rst->eviction ++;
	for(i = 0; i < cache->lineN; i++) {
		block = &cache->sets[seti].line[i];
		if(block->time == 1) {
			block->valid = 1;
			block->tag = tag;
			ut->seti = seti;
			ut->linei = i;
			if('M' != ch)	return MISSEVIC;
			rst->hit ++;
			return MEH;
		}
	}
	return type;
}


/* 
 * updateLRU searches the cache and decrease the 'time' of each valid block 
 * time of a new block is initialized as LINEn 
 */
int updateLRU(cache_t *cache, update_t *ut) {
	int i = 0;
	line_t *linei = NULL;
	line_t *block = &cache->sets[ut->seti].line[ut->linei];
	for(; i < cache->lineN; i++) {
		linei = &cache->sets[ut->seti].line[i];
		if(linei->valid ==1 && linei->time > block->time)
			linei->time --;
	} 
	block->time = cache->lineN;
	return 0;
}

