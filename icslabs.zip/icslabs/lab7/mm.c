/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your team information in the following struct.
 ********************************************************/
team_t team = {
    /* Team name */
    "yuhang",
    /* First member's full name */
    "yuhang",
    /* First member's email address */
    "515030910284",
    /* Second member's full name (leave blank if none) */
    "",
    /* Second member's email address (leave blank if none) */
    ""
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)


#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))


/* newly defined micro */
/* Basic constants and macros */
#define WSIZE		4
#define DSIZE		8
#define CHUNKSIZE	(1<<12)

#define MAX(x, y)	((x) > (y) ? (x) : (y))

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)	((size) | (alloc))

/* Read and write a word at address p */
#define GET(p)		(*(unsigned int *)(p))
#define PUT(p, val)	(*(unsigned int *)(p) = (val))

/* Read the size and allocated fields from addres p */
#define GET_SIZE(p)		(GET(p) & ~0x7)
#define GET_ALLOC(p)	(GET(p) & 0x1)

/* Given block ptr bp, compute address of its header and footer */
#define HDRP(bp)		((char *)(bp) - WSIZE)
#define FTRP(bp)		((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(bp)	((char *)(bp) + GET_SIZE(((char *)(bp) - WSIZE))) 
#define PREV_BLKP(bp)	((char *)(bp) - GET_SIZE(((char *)(bp) - DSIZE)))

/* Read and write a pointer at address p */
#define GET_PTR(p) ((unsigned int *)(long)(GET(p)))
#define PUT_PTR(p, ptr) (*(unsigned int *)(p) = ((long)ptr))

/* Opertation of the list pointer */
#define GET_NEXT_PTR(bp) (GET_PTR((unsigned int *)bp + 1))
#define NEXTI(bp) ((unsigned int *)bp + 1)


#define LISTN 16

static void *heap_listp;	//head block node of all heap blockk


static void *find_fit(size_t asize);
static void place(void *bp, size_t asize);
static void *coalesce(void *bp);
static void *extend_heapR(size_t words);

int mm_init(void);
void *mm_malloc(size_t size);
void mm_free(void *bp);
void *mm_realloc(void *ptr, size_t size);

int mm_check(void);

static void insertNode(void *bp);
static void removeNode(void *bp);
static int getIndex(size_t size);



/*
 * mm_check function checks for the following requirements:
 * 1. for all free list, every pointers in it must point to valid free block.
 * 2. for all free block, it must be in exactly one free list.
 * 3. there does not exist contiguous free blocks that escaped coalescing.
 * 4. information in the header must be consistent with that in the footer.
 */
int mm_check(void)
{
    void * bp; 
	int index;
    /* check for each free list */
	for(index = 0; index < LISTN; index++) {
		for(bp = GET_PTR(heap_listp + 4 * index); bp != NULL; bp = GET_PTR(bp))
			if (GET_ALLOC(HDRP(bp))) {		//check point 1
            	printf("block %p in free list has been allocated!\n", bp);
            	return 0;
        }
	}
	/* check fot each block */
    for (bp = heap_listp; GET_SIZE(HDRP(bp)) > 0; bp = NEXT_BLKP(bp)) {
        if (!GET_ALLOC(HDRP(bp))) {		//check point 2
            printf("block %p is ignored by any list!\n", bp);
            return 0;
        }
        if (!GET_ALLOC(HDRP(NEXT_BLKP(bp))) && !GET_ALLOC(HDRP(bp))) {		//check point 3
            printf("contiguous free blocks %p and %p escaped coalescing\n", bp, NEXT_BLKP(bp));
            return 0; 
        }
        if(GET(HDRP(bp)) != GET(FTRP(bp))) {
        	printf("header infomation (%x) differs to footer infomation (%x) in block %p\n", GET(HDRP(bp)), GET(FTRP(bp)), bp);
        	return 0;
		}
    }
    return 1;
}

static void *find_fit(size_t asize) 
{	
	int index;
	index = getIndex(asize);
	unsigned int *ptr, p;
	for(index = getIndex(asize); index < LISTN; index++) {
		for(ptr = GET_PTR(heap_listp + 4 * index); ptr != NULL; ptr = GET_PTR(ptr))
			if(GET_SIZE(HDRP(ptr)) >= asize)
				return (void *) ptr;
	}
	ptr = extend_heapR(MAX(asize, CHUNKSIZE));
	insertNode(ptr);
	return ptr;
}

static void place(void *bp, size_t asize) 
{
	size_t csize = GET_SIZE(HDRP(bp));
	removeNode(bp);
	if((csize - asize) >= (2*DSIZE)) {
		PUT(HDRP(bp), PACK(asize, 1));
		PUT(FTRP(bp), PACK(asize, 1));
		bp = NEXT_BLKP(bp);
		PUT(HDRP(bp), PACK(csize-asize, 0));
		PUT(FTRP(bp), PACK(csize-asize, 0));
		insertNode(bp);
	}
	else {
		PUT(HDRP(bp), PACK(csize, 1));
		PUT(FTRP(bp), PACK(csize, 1));
	}
}


static void *coalesce(void *bp)
{
	size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
	
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	
	size_t size = GET_SIZE(HDRP(bp));
	
	if ( prev_alloc && next_alloc ){ 
        ;
	}		
	
	else if ( prev_alloc && !next_alloc ) { 
		removeNode(NEXT_BLKP(bp));
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		PUT(HDRP(bp), PACK(size, 0));
		PUT(FTRP(bp), PACK(size, 0));
	}
	
	else if ( !prev_alloc && next_alloc ) {
		removeNode(PREV_BLKP(bp));
	    size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		PUT(FTRP(bp), PACK(size, 0));
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
	}
	
	else {
		removeNode(NEXT_BLKP(bp));
		removeNode(PREV_BLKP(bp));
		size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(HDRP(NEXT_BLKP(bp)));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
	}
	insertNode(bp);
	return bp;
}

/* 
 * mm_init - initialize the malloc package.
 */
int mm_init(void)
{
    /* create the initial empty heap */
	if ((heap_listp = mem_sbrk((LISTN + 4) * WSIZE)) == (void *)-1) {
		return -1;
	}
	PUT(heap_listp + LISTN * WSIZE, 0);
	PUT(heap_listp + (1 + LISTN) * WSIZE, PACK(DSIZE, 1));
	PUT(heap_listp + (2 + LISTN) * WSIZE, PACK(DSIZE, 1));
	PUT(heap_listp + (3 + LISTN) * WSIZE, PACK(0, 1));
	/* initialize the LISTN lists */
	int i = 0;
	for (i = 0; i < LISTN; i++) {
		PUT_PTR(heap_listp + WSIZE * i, NULL);
	}

	/* Extend the empty heap with a free block of CHUNKSIZE bytes */
	/*if (extend_heapR(CHUNKSIZE / DSIZE) == NULL)
		return -1;*/
	insertNode(extend_heapR(CHUNKSIZE/DSIZE));
	return 0;
}


/* 
 * mm_malloc - Allocate a block by incrementing the brk pointer.
 *     Always allocate a block whose size is a multiple of the alignment.
 */
void *mm_malloc(size_t size)
{
    size_t asize; /* adjusted block size */
    char *bp;
    
    /* Ignore spurious requests */
    if( size <= 0 )
        return NULL;
        
    /* Adjust block size to include overhead and alignment requirements. */
    if (size <= DSIZE)
    	asize = 2 * DSIZE;
    else
    	asize = DSIZE * ((size + (DSIZE) + (DSIZE-1)) / DSIZE);
    	
    /* Search the free list for a fit */
    bp = find_fit(asize);
    place(bp, asize);
    return bp;
}

/*
 * mm_free - Freeing a block does nothing.
 */
void mm_free(void *bp)
{
	size_t size = GET_SIZE(HDRP(bp));
	
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
	coalesce(bp);
	
}


void *mm_realloc(void *bp, size_t size)
{
    void *ptr;
    size_t bsize = GET_SIZE(HDRP(bp));
    size_t asize = ALIGN(size + DSIZE);
    size_t nsize = GET_SIZE(HDRP(NEXT_BLKP(bp)));
    if (size == 0) {
        mm_free(bp);
        return NULL;
    } else { 
		/* extend the heap, don't change the list */
        if (GET_SIZE(HDRP(NEXT_BLKP(bp))) == 0) { 
            extend_heapR(asize - bsize);
            PUT(HDRP(bp), PACK(asize, 1));
            PUT(FTRP(bp), PACK(asize, 1));
        }  else if (!GET_ALLOC(HDRP(NEXT_BLKP(bp))) && (bsize + nsize >= asize)) { 
            removeNode(NEXT_BLKP(bp));
            bsize += nsize;
            PUT(HDRP(bp), PACK(bsize, 1));
            place(bp, asize);
        }else {
            ptr = mm_malloc(size);
            if (ptr == NULL)
              return NULL;
            memcpy(ptr, bp, size);
            mm_free(bp);
            bp = ptr;
        }
    }
    return bp;
}

/* 
 * special expend_heap func to optimize realloc and other func
 * sepreate the operation of coalease and the extension, optimising the utility
 */
static void *extend_heapR(size_t words)
{
	char *bp;
	size_t size;
	
	/* Allocate an even number of words to maintain alignment */
	size = ALIGN(words);
	if((bp = mem_sbrk(size)) == (char *)-1)
		return NULL;
	
	/* Initialize free block header/footer and the epilogue header */
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1));
	return bp;
}



/* insert a node into the head of a list */
void insertNode(void *bp)
{
	int index;
	void *headi;
	size_t size;
	size = GET_SIZE(HDRP(bp));
	index = getIndex(size);
	headi = heap_listp + WSIZE * index;
	if (!GET_PTR(headi)) { /* the head of list point to NULL */
		PUT_PTR(bp, NULL);
	} else {    /* the list is not empty, insert new one into the head*/ 
		PUT_PTR(bp, GET_PTR(headi));
		PUT_PTR(GET_PTR(headi) + 1, bp);  		
	}
	PUT_PTR(NEXTI(bp), NULL);
	PUT_PTR(headi, bp);
}

/* remove node in the search list */
void removeNode(void *bp)
{
    int index;
    size_t size;
    size = GET_SIZE(HDRP(bp));
    index = getIndex(size);
    if (!GET_PTR(bp) && !GET_NEXT_PTR(bp) ) { 
        /* erase the only node in the list ,just set NULL */
        PUT_PTR(heap_listp + WSIZE * index, NULL);
    } else if (!GET_PTR(bp) && GET_NEXT_PTR(bp)) {
        /* the last node in the list, just set the prev to NULL */
        PUT_PTR(GET_NEXT_PTR(bp), NULL);
    } else if (GET_PTR(bp) && !GET_NEXT_PTR(bp) ){
        /* remove the first node in teh list, operate twice*/
        PUT_PTR(heap_listp + WSIZE * index, GET_PTR(bp));
        PUT_PTR(GET_PTR(bp) + 1, NULL);
    } else if (GET_PTR(bp) && GET_NEXT_PTR(bp) ) {
        /* remove the medain node, operate like bp->prev = bp->next*/
        PUT_PTR(GET_NEXT_PTR(bp), GET_PTR(bp));
        PUT_PTR(GET_PTR(bp) + 1, GET_NEXT_PTR(bp));
    }
}


/* find the index in the list */
int getIndex(size_t size) {
	int index = 0;
	while(size != 0) {
		size >>= 1;
		index ++;
	}
	index = (index == 0) ? 0 : index-4;
	index = (index > LISTN - 1) ? (LISTN - 1) : index;
	return index;	
}

